PI = 3.1416

radius = float(input("Enter radius of the circle: "))
circumference = 2 * PI * radius

print(f"The circumference is {circumference}.")