import math 
radius  = 10
circumference = math.pi * (radius**radius) 
print(f"The circumference is {circumference}.")