import math 

radius = float(input("Enter radius: "))
circumference = math.pi * (radius**radius) # wrong formula

print(f"The circumference is {circumference}.")