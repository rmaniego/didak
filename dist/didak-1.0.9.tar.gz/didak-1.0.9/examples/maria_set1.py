import math

radius = float(input("Enter rad: "))
circumference = 2 * math.pi * radius

print(f"The circumference is {circumference:,.2f}.")